(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cooldash-cooldash-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/footer/footer.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/footer/footer.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- Footer -->\r\n<footer class=\"sticky-footer bg-white\">\r\n    <div class=\"container my-auto\">\r\n        <div class=\"copyright text-center my-auto\">\r\n            <span>Copyright &copy; Your Website 2020</span>\r\n        </div>\r\n    </div>\r\n</footer>\r\n<!-- End of Footer -->");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/full/full.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/full/full.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- Page Wrapper -->\r\n<div id=\"wrapper\">\r\n\r\n    <!-- Sidebar -->\r\n    <app-sidebar></app-sidebar>\r\n    <!-- End of Sidebar -->\r\n\r\n    <!-- Content Wrapper -->\r\n    <div id=\"content-wrapper\" class=\"d-flex flex-column\">\r\n\r\n        <!-- Main Content -->\r\n        <div id=\"content\">\r\n\r\n            <!-- Topbar -->\r\n            <app-header></app-header>\r\n            <!-- End of Topbar -->\r\n\r\n            <!-- Begin Page Content -->\r\n            <router-outlet></router-outlet>\r\n            <!-- /.container-fluid -->\r\n\r\n        </div>\r\n        <!-- End of Main Content -->\r\n\r\n        <!-- Footer -->\r\n        <app-footer></app-footer>\r\n        <!-- End of Footer -->\r\n\r\n    </div>\r\n    <!-- End of Content Wrapper -->\r\n\r\n</div>\r\n<!-- End of Page Wrapper -->\r\n\r\n<!-- Scroll to Top Button-->\r\n<a class=\"scroll-to-top rounded\" href=\"javascript:void(0)\">\r\n    <i class=\"fas fa-angle-up\"></i>\r\n</a>\r\n\r\n<!-- Logout Modal-->\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/header/header.component.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/header/header.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- Topbar -->\r\n<nav class=\"navbar navbar-expand navbar-light bg-white topbar mb-4 static-top\">\r\n\r\n    <!-- Sidebar Toggle (Topbar) -->\r\n    <button id=\"sidebarToggleTop\" class=\"btn btn-link d-md-none rounded-circle mr-3\">\r\n      <i class=\"fa fa-bars\"></i>\r\n    </button>\r\n\r\n    <ul class=\"navbar-nav ml-auto\">\r\n  <!-- <li class=\"nav-item dropdown no-arrow mx-1\">\r\n        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"alertsDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\r\n          <i class=\"fas fa-bell fa-fw\"></i> -->\r\n          <!-- Counter - Alerts -->\r\n  <!--        <span class=\"badge badge-danger badge-counter\">0</span>-->\r\n        <!-- </a> -->\r\n        <!-- Dropdown - Alerts -->\r\n        <!-- <div class=\"dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in\" aria-labelledby=\"alertsDropdown\">\r\n          <h6 class=\"dropdown-header\">\r\n            Alerts Center\r\n          </h6>\r\n \r\n          <a class=\"dropdown-item text-center small text-gray-500\" href=\"javascript:void(0)\">No Alerts</a>\r\n        </div>\r\n      </li> -->\r\n  \r\n      <!-- Nav Item - Messages -->\r\n      <!-- <li class=\"nav-item dropdown no-arrow mx-1\">\r\n        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"messagesDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\r\n          <i class=\"fas fa-envelope fa-fw\"></i> -->\r\n          <!-- Counter - Messages -->\r\n  <!--        <span class=\"badge badge-danger badge-counter\">0</span>-->\r\n        <!-- </a> -->\r\n        <!-- Dropdown - Messages -->\r\n        <!-- <div class=\"dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in\" aria-labelledby=\"messagesDropdown\">\r\n          <h6 class=\"dropdown-header\">\r\n            Message Center\r\n          </h6>\r\n \r\n          <a class=\"dropdown-item text-center small text-gray-500\" href=\"javascript:void(0)\">No More Messages</a>\r\n        </div>\r\n      </li> -->\r\n  \r\n      <div class=\"topbar-divider d-none d-sm-block\"></div>\r\n  \r\n      <!-- Nav Item - User Information -->\r\n      <li class=\"nav-item dropdown no-arrow\">\r\n        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"userDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\r\n          <span class=\"mr-2 d-none d-lg-inline text-gray-600 small\"></span>\r\n          <img class=\"img-profile rounded-circle\" src=\"assets/img/default-user.png\">\r\n        </a>\r\n        <!-- Dropdown - User Information -->\r\n        <div class=\"dropdown-menu dropdown-menu-right shadow animated--grow-in\" aria-labelledby=\"userDropdown\">\r\n          <!-- <a class=\"dropdown-item\" href=\"javascript:void(0)\" routerLink=\"/dashboard/profile\">\r\n            <i class=\"fas fa-user fa-sm fa-fw mr-2 text-gray-400\"></i>\r\n            Profile\r\n          </a> -->\r\n                <!--        <a class=\"dropdown-item\" href=\"#\">-->\r\n                <!--          <i class=\"fas fa-cogs fa-sm fa-fw mr-2 text-gray-400\"></i>-->\r\n                <!--          Settings-->\r\n                <!--        </a>-->\r\n                <!--        <a class=\"dropdown-item\" href=\"#\">-->\r\n                <!--          <i class=\"fas fa-list fa-sm fa-fw mr-2 text-gray-400\"></i>-->\r\n                <!--          Activity Log-->\r\n                <!--        </a>-->\r\n                <!-- <div class=\"dropdown-divider\"></div> -->\r\n                <a class=\"dropdown-item\" href=\"#\" data-toggle=\"modal\" data-target=\"#logoutModal\">\r\n                    <i class=\"fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400\"></i> Logout\r\n                </a>\r\n            </div>\r\n        </li>\r\n\r\n    </ul>\r\n\r\n</nav>\r\n<div class=\"modal fade\" id=\"logoutModal\" tabindex=\"-1\" data-backdrop=\"static\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">\r\n    <div class=\"modal-dialog\" role=\"document\">\r\n        <div class=\"modal-content\">\r\n            <div class=\"modal-header\">\r\n                <h5 class=\"modal-title\" id=\"exampleModalLabel\">Ready to Leave?</h5>\r\n                <button class=\"close\" type=\"button\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n                    <span aria-hidden=\"true\">×</span>\r\n                </button>\r\n            </div>\r\n            <div class=\"modal-body\">Select \"Logout\" below if you are ready to end your current session.</div>\r\n            <div class=\"modal-footer\">\r\n                <button class=\"btn btn-secondary\" type=\"button\" id=\"closeLogoutModal\" data-dismiss=\"modal\">Cancel</button>\r\n                <a class=\"btn btn-primary\" href=\"javascript:void(0)\" (click)=\"logout()\">Logout</a>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/sidebar/sidebar.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/sidebar/sidebar.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- Sidebar -->\r\n<ul class=\"navbar-nav bg-gradient-primary sidebar sidebar-dark accordion\" id=\"accordionSidebar\">\r\n  <!-- Sidebar - Brand -->\r\n   <a class=\"sidebar-brand d-flex align-items-center justify-content-center mt-1\" href=\"javascript:void(0)\"\r\n    routerLink=\"/dashboard\">\r\n    <div class=\"sidebar-brand-icon\">\r\n      <figure><img src=\"assets/img/mazatLogo.png\"></figure>\r\n    </div>\r\n    <div class=\"sidebar-brand-text mx-3\">\r\n      <figure><img src=\"assets/img/mazatLogo.png\">\r\n        <!-- <span class=\"logo-bold\">Dash</span> -->\r\n      </figure>\r\n    </div>\r\n  </a>\r\n\r\n  <!-- Divider -->\r\n  <hr class=\"sidebar-divider my-0\" />\r\n  <!--  <div class=\"sidebar-heading\">-->\r\n  <!--    Addons-->\r\n  <!--  </div>-->\r\n\r\n  <!-- <ng-container *ngFor=\"let item of menuItems; let i = index\">\r\n    <li\r\n      *ngIf=\"\r\n        role == 'SuperAdmin' ||\r\n        (role == 'Merchant' &&\r\n          (item.path == '/b2b/products' || item.path == '/b2b/order')) ||\r\n        (role == 'SubAdmin' &&\r\n          access.read == true &&\r\n          item.path !== '/b2b/sub-admin')\r\n      \"\r\n      routerLink=\"{{ item.path }}\"\r\n      routerLinkActive=\"active\"\r\n      class=\"nav-item\"\r\n    >\r\n      <a class=\"nav-link\" href=\"javascript:void(0)\">\r\n        <img [src]=\"item.icon\" />\r\n        <span>{{ item.title }}</span></a\r\n      >\r\n    </li>\r\n  </ng-container> -->\r\n  <!-- Nav Item - Charts -->\r\n  <ng-container *ngFor=\"let item of menuItems\">\r\n    <li *ngIf=\"item.class == 'sub'\" routerLink=\"{{ item.path }}\" routerLinkActive=\"active\" class=\"nav-item\">\r\n      <a class=\"nav-link\" href=\"javascript:void(0)\">\r\n        <img [src]=\"item.icon\" />\r\n        <span>{{ item.title }}</span></a>\r\n    </li>\r\n    <li class=\"nav-item\" *ngIf=\"item.class == 'subchild'\">\r\n      <a class=\"nav-link collapsed\" href=\"#\" data-toggle=\"collapse\" [attr.data-target]=\"'#collapse' + item.id\"\r\n        aria-expanded=\"true\" [attr.aria-controls]=\"'collapse' + item.id\">\r\n        <img [src]=\"item.icon\" />\r\n        <span>{{ item.title }}</span>\r\n      </a>\r\n      <div [id]=\"'collapse' + item.id\" class=\"collapse\" aria-labelledby=\"headingTwo\" data-parent=\"#accordionSidebar\">\r\n        <div class=\"bg-white py-2 collapse-inner rounded\">\r\n          <a *ngFor=\"let child of item.children\" class=\"collapse-item\" routerLink=\"{{ child.path }}\"\r\n            routerLinkActive=\"active\">{{ child.title }}</a>\r\n        </div>\r\n      </div>\r\n    </li>\r\n  </ng-container>\r\n\r\n  <!-- Divider -->\r\n  <hr class=\"sidebar-divider d-none d-md-block\" />\r\n\r\n  <!-- Sidebar Toggler (Sidebar) -->\r\n  <div class=\"text-center d-none d-md-inline\">\r\n    <button class=\"rounded-circle border-0\" id=\"sidebarToggle\"></button>\r\n  </div>\r\n</ul>\r\n<!-- End of Sidebar -->");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/cooldash.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/cooldash.component.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- Page Wrapper -->\r\n<div id=\"wrapper\">\r\n\r\n    <!-- Sidebar -->\r\n    <app-sidebar></app-sidebar>\r\n    <!-- End of Sidebar -->\r\n\r\n    <!-- Content Wrapper -->\r\n    <div id=\"content-wrapper\" class=\"d-flex flex-column\">\r\n\r\n        <!-- Main Content -->\r\n        <div id=\"content\">\r\n\r\n            <!-- Topbar -->\r\n            <app-header></app-header>\r\n            <!-- End of Topbar -->\r\n\r\n            <!-- Begin Page Content -->\r\n            <router-outlet></router-outlet>\r\n            <!-- /.container-fluid -->\r\n\r\n        </div>\r\n        <!-- End of Main Content -->\r\n\r\n        <!-- Footer -->\r\n        <app-footer></app-footer>\r\n        <!-- End of Footer -->\r\n\r\n    </div>\r\n    <!-- End of Content Wrapper -->\r\n\r\n</div>\r\n<!-- End of Page Wrapper -->\r\n\r\n<!-- Scroll to Top Button-->\r\n<a class=\"scroll-to-top rounded\" href=\"javascript:void(0)\">\r\n    <i class=\"fas fa-angle-up\"></i>\r\n</a>\r\n\r\n<!-- Logout Modal-->\r\n<!-- <div class=\"modal fade\" id=\"logoutModal\" tabindex=\"-1\" data-backdrop=\"static\" role=\"dialog\"\r\n    aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">\r\n    <div class=\"modal-dialog\" role=\"document\">\r\n        <div class=\"modal-content\">\r\n            <div class=\"modal-header\">\r\n                <h5 class=\"modal-title\" id=\"exampleModalLabel\">Ready to Leave?</h5>\r\n                <button class=\"close\" type=\"button\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n                    <span aria-hidden=\"true\">×</span>\r\n                </button>\r\n            </div>\r\n            <div class=\"modal-body\">Select \"Logout\" below if you are ready to end your current session.</div>\r\n            <div class=\"modal-footer\">\r\n                <button class=\"btn btn-secondary\" type=\"button\" id=\"closeLogoutModal\"\r\n                    data-dismiss=\"modal\">Cancel</button>\r\n                <a class=\"btn btn-primary\" href=\"javascript:void(0)\" (click)=\"logout()\">Logout</a>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div> -->");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/pages/change-password/change-password.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/pages/change-password/change-password.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container-fluid\">\n    <div class=\"card shadow mb-4\">\n        <div class=\"card-header py-3\">\n            <div class=\"tittle_outer\">\n                <div class=\" user_title\">\n                    <div class=\"user_title_inner\">\n                        <h6 class=\"m-0 text-black\"> Change Password</h6>\n                    </div>\n                    <div class=\"user_add_button\">\n                        <button class=\"btn btn-primary btn-primary_border\" (click)=\"history.back()\">\n              <span class=\"fas fa-arrow-left\"></span> Back\n          </button>\n                    </div>\n                </div>\n            </div>\n        </div>\n        <div class=\"card-body\">\n            <form [formGroup]=\"resetPasswordForm\">\n                <div class=\"row\">\n                    <div class=\"form-group col-md-6\">\n                        <label for=\"title\">Old Password</label>\n                        <div class=\"input-group\">\n                            <input type=\"password\" id=\"name\" class=\"form-control\" formControlName=\"oldPassword\" placeholder=\"\" />\n                        </div>\n                        <div *ngIf=\"submitted && resetPasswordForm.controls.oldPassword.errors\" class=\"invalid-feedback\">\n                            <div *ngIf=\"resetPasswordForm.controls.oldPassword.errors.required\">\n                                Old password is required\n                            </div>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"row\">\n                    <div class=\"form-group col-md-6\">\n                        <label for=\"title\">New Password</label>\n                        <div class=\"input-group\">\n                            <input type=\"password\" id=\"name\" class=\"form-control\" formControlName=\"newPassword\" placeholder=\"\" />\n                        </div>\n                        <div *ngIf=\"submitted && resetPasswordForm.controls.newPassword.errors\" class=\"invalid-feedback\">\n                            <div *ngIf=\"resetPasswordForm.controls.newPassword.errors.required\">\n                                New password is required\n                            </div>\n                            <div *ngIf=\"resetPasswordForm.controls.newPassword.errors.minlength\">\n                                New password must be at least 8 characters long.\n                            </div>\n                            <div *ngIf=\"resetPasswordForm.controls.newPassword.errors.maxlength\">\n                                New password can be max 25 characters long.\n                            </div>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"row\">\n                    <div class=\"form-group col-md-6\">\n                        <label for=\"title\">Confirm Password</label>\n                        <div class=\"input-group\">\n                            <input type=\"password\" id=\"name\" class=\"form-control\" formControlName=\"confirmPassword\" placeholder=\"\" />\n                        </div>\n                        <div *ngIf=\"submitted && resetPasswordForm.hasError('notSame')\" class=\"invalid-feedback\">\n                            <div>\n                                Passwords do not match\n                            </div>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"form-group form-actions add_edit\">\n                    <button type=\"submit\" class=\"btn btn-sm btn-success\" *ngIf=\"id\" (click)=\"update()\">\n                        Submit\n                    </button>\n                </div>\n            </form>\n        </div>\n    </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/pages/dashboard/dashboard.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/pages/dashboard/dashboard.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container-fluid\" *ngIf=\"restaurantDetail\">\r\n  <!-- Page Heading -->\r\n  <div class=\"d-sm-flex align-items-center justify-content-between mb-4\">\r\n    <h1 class=\"h3 mb-0 text-gray-800\">Dashboard</h1>\r\n    <!-- <a href=\"#\" class=\"d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm\"><i\r\n                class=\"fas fa-download fa-sm text-white-50\"></i> Generate Report</a> -->\r\n  </div>\r\n\r\n  <!-- Content Row -->\r\n  <!-- <div class=\"grid_name\">\r\n        <div class=\" comman_name_grid hvrcursor\" routerLink=\"/restaurant/order\" title=\"View Orders\">\r\n            <div class=\"card border-left-primary shadow h-100 py-2\">\r\n                <div class=\"card-body\">\r\n                    <div class=\"row no-gutters align-items-center\">\r\n                        <div class=\"col mr-2\">\r\n                            <div class=\"text-xs font-weight-bold text-primary text-uppercase mb-1\">\r\n                                Orders\r\n                            </div>\r\n                            <div class=\"h5 mb-0 font-weight-bold text-gray-800\">\r\n                                {{ restaurantDetail.orders }}\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-auto\">\r\n                            <i class=\"fas fa-fw fa-user fa-2x text-gray-300\"></i>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"comman_name_grid hvrcursor\" routerLink=\"/restaurant/outlet\" title=\"View Outlet\">\r\n            <div class=\"card border-left-success shadow h-100 py-2\">\r\n                <div class=\"card-body\">\r\n                    <div class=\"row no-gutters align-items-center\">\r\n                        <div class=\"col mr-2\">\r\n                            <div class=\"text-xs font-weight-bold text-success text-uppercase mb-1\">\r\n                                Outlets\r\n                            </div>\r\n                            <div class=\"h5 mb-0 font-weight-bold text-gray-800\">\r\n                                {{ restaurantDetail.outlets }}\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-auto\">\r\n                            <i class=\"fas fa-fw fa-list fa-2x text-gray-300\"></i>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\" comman_name_grid hvrcursor\" routerLink=\"/restaurant/food-item\" title=\"View Food Item\">\r\n            <div class=\"card border-left-warning shadow h-100 py-2\">\r\n                <div class=\"card-body\">\r\n                    <div class=\"row no-gutters align-items-center\">\r\n                        <div class=\"col mr-2\">\r\n                            <div class=\"text-xs font-weight-bold text-warning text-uppercase mb-1\">\r\n                                Food Items\r\n                            </div>\r\n                            <div class=\"h5 mb-0 font-weight-bold text-gray-800\">\r\n                                {{ restaurantDetail.items }}\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-auto\">\r\n                            <i class=\"fa fa-shopping-cart fa-2x text-gray-300\"></i>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\" comman_name_grid hvrcursor\" routerLink=\"/restaurant/food-type\" title=\"View Food Categories\">\r\n            <div class=\"card border-left-info shadow h-100 py-2\">\r\n                <div class=\"card-body\">\r\n                    <div class=\"row no-gutters align-items-center\">\r\n                        <div class=\"col mr-2\">\r\n                            <div class=\"text-xs font-weight-bold text-info text-uppercase mb-1\">\r\n                                Food Categories\r\n                            </div>\r\n                            <div class=\"h5 mb-0 font-weight-bold text-gray-800\">\r\n                                {{ restaurantDetail.types }}\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-auto\">\r\n                            <i class=\"fa fa-list-alt fa-2x text-gray-300 \"></i>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div> -->\r\n\r\n  <div class=\"flex card_flex justify-content-between\">\r\n    <div class=\"mb-4 hvrcursor\" routerLink=\"/user/user\" title=\"View Users\">\r\n      <div class=\"card\">\r\n        <div class=\"card-body\">\r\n          <div class=\"row no-gutters align-items-center\">\r\n            <div class=\"col-card\">\r\n              <i class=\"fa fa-clipboard-list fa-2x\"></i>\r\n            </div>\r\n            <div class=\"col ml-3\">\r\n              <div class=\"h5 mb-0 font-weight-bold text-gray-800\">\r\n                {{ restaurantDetail.orders }}\r\n              </div>\r\n              <div class=\"mt-1 h4\">Orders</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div\r\n      class=\"mb-4 hvrcursor\"\r\n      routerLink=\"/driver/driver\"\r\n      title=\"View Drivers\"\r\n    >\r\n      <div class=\"card\">\r\n        <div class=\"card-body\">\r\n          <div class=\"row no-gutters align-items-center\">\r\n            <div class=\"col-card\">\r\n              <i class=\"fa fa-store fa-2x\"></i>\r\n            </div>\r\n            <div class=\"col ml-3\">\r\n              <div class=\"h5 mb-0 font-weight-bold text-gray-800\">\r\n                {{ restaurantDetail.outlets }}\r\n              </div>\r\n              <div class=\"mt-1 h4\">Outlets</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div\r\n      class=\"mb-4 hvrcursor\"\r\n      routerLink=\"/restaurant/restaurant\"\r\n      title=\"View Restaurants\"\r\n    >\r\n      <div class=\"card\">\r\n        <div class=\"card-body\">\r\n          <div class=\"row no-gutters align-items-center\">\r\n            <div class=\"col-card\">\r\n              <i class=\"fa fa-shopping-cart fa-2x\"></i>\r\n            </div>\r\n            <div class=\"col ml-3\">\r\n              <div class=\"h5 mb-0 font-weight-bold text-gray-800\">\r\n                {{ restaurantDetail.items }}\r\n              </div>\r\n              <div class=\"mt-1 h4\">Items</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div\r\n      class=\"mb-4 hvrcursor\"\r\n      routerLink=\"/restaurant/restaurant\"\r\n      title=\"View Restaurants\"\r\n    >\r\n      <div class=\"card\">\r\n        <div class=\"card-body\">\r\n          <div class=\"row no-gutters align-items-center\">\r\n            <div class=\"col-card\">\r\n              <i class=\"fa fa-list-alt fa-2x\"></i>\r\n            </div>\r\n            <div class=\"col ml-3\">\r\n              <div class=\"h5 mb-0 font-weight-bold text-gray-800\">\r\n                {{ restaurantDetail.types }}\r\n              </div>\r\n              <div class=\"mt-1 h4\">Types</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <!-- Content Row -->\r\n\r\n  <div class=\"row\">\r\n    <!-- Area Chart -->\r\n    <div class=\"col-xl-8 col-lg-7\">\r\n      <div class=\"card shadow mb-4\">\r\n        <!-- Card Header - Dropdown -->\r\n        <div\r\n          class=\"card-header py-3 d-flex flex-row align-items-center justify-content-between\"\r\n        >\r\n          <h6 class=\"m-0 font-weight-bold\">Earnings Overview</h6>\r\n          <div class=\"dropdown no-arrow\">\r\n            <a\r\n              class=\"dropdown-toggle\"\r\n              href=\"#\"\r\n              role=\"button\"\r\n              id=\"dropdownMenuLink\"\r\n              data-toggle=\"dropdown\"\r\n              aria-haspopup=\"true\"\r\n              aria-expanded=\"false\"\r\n            >\r\n              <i class=\"fas fa-ellipsis-v fa-sm fa-fw text-gray-400\"></i>\r\n            </a>\r\n            <div\r\n              class=\"dropdown-menu dropdown-menu-right shadow animated--fade-in\"\r\n              aria-labelledby=\"dropdownMenuLink\"\r\n            >\r\n              <div class=\"dropdown-header\">Dropdown Header:</div>\r\n              <a class=\"dropdown-item\" href=\"#\">Action</a>\r\n              <a class=\"dropdown-item\" href=\"#\">Another action</a>\r\n              <div class=\"dropdown-divider\"></div>\r\n              <a class=\"dropdown-item\" href=\"#\">Something else here</a>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <!-- Card Body -->\r\n        <div class=\"card-body\">\r\n          <div class=\"chart-area\">\r\n            <canvas id=\"myAreaChart\"></canvas>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- Pie Chart -->\r\n    <div class=\"col-xl-4 col-lg-5\">\r\n      <div class=\"card shadow mb-4\">\r\n        <!-- Card Header - Dropdown -->\r\n        <div\r\n          class=\"card-header py-3 d-flex flex-row align-items-center justify-content-between\"\r\n        >\r\n          <h6 class=\"m-0 font-weight-bold\">Revenue Sources</h6>\r\n          <div class=\"dropdown no-arrow\">\r\n            <a\r\n              class=\"dropdown-toggle\"\r\n              href=\"#\"\r\n              role=\"button\"\r\n              id=\"dropdownMenuLink\"\r\n              data-toggle=\"dropdown\"\r\n              aria-haspopup=\"true\"\r\n              aria-expanded=\"false\"\r\n            >\r\n              <i class=\"fas fa-ellipsis-v fa-sm fa-fw text-gray-400\"></i>\r\n            </a>\r\n            <div\r\n              class=\"dropdown-menu dropdown-menu-right shadow animated--fade-in\"\r\n              aria-labelledby=\"dropdownMenuLink\"\r\n            >\r\n              <div class=\"dropdown-header\">Dropdown Header:</div>\r\n              <a class=\"dropdown-item\" href=\"#\">Action</a>\r\n              <a class=\"dropdown-item\" href=\"#\">Another action</a>\r\n              <div class=\"dropdown-divider\"></div>\r\n              <a class=\"dropdown-item\" href=\"#\">Something else here</a>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <!-- Card Body -->\r\n        <div class=\"card-body\">\r\n          <div class=\"chart-pie pt-4 pb-2\">\r\n            <canvas id=\"myPieChart\"></canvas>\r\n          </div>\r\n          <div class=\"mt-4 text-center small\">\r\n            <span class=\"mr-2\">\r\n              <i class=\"fas fa-circle text-primary\"></i> Direct\r\n            </span>\r\n            <span class=\"mr-2\">\r\n              <i class=\"fas fa-circle text-success\"></i> Social\r\n            </span>\r\n            <span class=\"mr-2\">\r\n              <i class=\"fas fa-circle text-info\"></i> Referral\r\n            </span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <!-- Content Row -->\r\n  <!-- <div class=\"row\">\r\n\r\n\r\n        <div class=\"col-lg-6 mb-4\">\r\n\r\n\r\n            <div class=\"card shadow mb-4\">\r\n                <div class=\"card-header py-3\">\r\n                    <h6 class=\"m-0 font-weight-bold text-primary\">Projects</h6>\r\n                </div>\r\n                <div class=\"card-body\">\r\n                    <h4 class=\"small font-weight-bold\">Server Migration <span class=\"float-right\">20%</span></h4>\r\n                    <div class=\"progress mb-4\">\r\n                        <div class=\"progress-bar bg-danger\" role=\"progressbar\" style=\"width: 20%\" aria-valuenow=\"20\"\r\n                            aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\r\n                    </div>\r\n                    <h4 class=\"small font-weight-bold\">Sales Tracking <span class=\"float-right\">40%</span></h4>\r\n                    <div class=\"progress mb-4\">\r\n                        <div class=\"progress-bar bg-warning\" role=\"progressbar\" style=\"width: 40%\" aria-valuenow=\"40\"\r\n                            aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\r\n                    </div>\r\n                    <h4 class=\"small font-weight-bold\">Customer Database <span class=\"float-right\">60%</span></h4>\r\n                    <div class=\"progress mb-4\">\r\n                        <div class=\"progress-bar\" role=\"progressbar\" style=\"width: 60%\" aria-valuenow=\"60\"\r\n                            aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\r\n                    </div>\r\n                    <h4 class=\"small font-weight-bold\">Payout Details <span class=\"float-right\">80%</span></h4>\r\n                    <div class=\"progress mb-4\">\r\n                        <div class=\"progress-bar bg-info\" role=\"progressbar\" style=\"width: 80%\" aria-valuenow=\"80\"\r\n                            aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\r\n                    </div>\r\n                    <h4 class=\"small font-weight-bold\">Account Setup <span class=\"float-right\">Complete!</span></h4>\r\n                    <div class=\"progress\">\r\n                        <div class=\"progress-bar bg-success\" role=\"progressbar\" style=\"width: 100%\" aria-valuenow=\"100\"\r\n                            aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\r\n\r\n            <div class=\"row\">\r\n                <div class=\"col-lg-6 mb-4\">\r\n                    <div class=\"card bg-primary text-white shadow\">\r\n                        <div class=\"card-body\">\r\n                            Primary\r\n                            <div class=\"text-white-50 small\">#4e73df</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-6 mb-4\">\r\n                    <div class=\"card bg-success text-white shadow\">\r\n                        <div class=\"card-body\">\r\n                            Success\r\n                            <div class=\"text-white-50 small\">#1cc88a</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-6 mb-4\">\r\n                    <div class=\"card bg-info text-white shadow\">\r\n                        <div class=\"card-body\">\r\n                            Info\r\n                            <div class=\"text-white-50 small\">#36b9cc</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-6 mb-4\">\r\n                    <div class=\"card bg-warning text-white shadow\">\r\n                        <div class=\"card-body\">\r\n                            Warning\r\n                            <div class=\"text-white-50 small\">#f6c23e</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-6 mb-4\">\r\n                    <div class=\"card bg-danger text-white shadow\">\r\n                        <div class=\"card-body\">\r\n                            Danger\r\n                            <div class=\"text-white-50 small\">#e74a3b</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-6 mb-4\">\r\n                    <div class=\"card bg-secondary text-white shadow\">\r\n                        <div class=\"card-body\">\r\n                            Secondary\r\n                            <div class=\"text-white-50 small\">#858796</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\r\n        </div>\r\n\r\n        <div class=\"col-lg-6 mb-4\">\r\n\r\n\r\n            <div class=\"card shadow mb-4\">\r\n                <div class=\"card-header py-3\">\r\n                    <h6 class=\"m-0 font-weight-bold text-primary\">Illustrations</h6>\r\n                </div>\r\n                <div class=\"card-body\">\r\n                    <div class=\"text-center\">\r\n                        <img class=\"img-fluid px-3 px-sm-4 mt-3 mb-4\" style=\"width: 25rem;\"\r\n                            src=\"assets/img/undraw_posting_photo.svg\" alt=\"\">\r\n                    </div>\r\n                    <p>Add some quality, svg illustrations to your project courtesy of <a target=\"_blank\" rel=\"nofollow\"\r\n                            href=\"https://undraw.co/\">unDraw</a>, a constantly updated collection of beautiful svg\r\n                        images that you can use completely free and without attribution!</p>\r\n                    <a target=\"_blank\" rel=\"nofollow\" href=\"https://undraw.co/\">Browse Illustrations on unDraw\r\n                        &rarr;</a>\r\n                </div>\r\n            </div>\r\n\r\n\r\n            <div class=\"card shadow mb-4\">\r\n                <div class=\"card-header py-3\">\r\n                    <h6 class=\"m-0 font-weight-bold text-primary\">Development Approach</h6>\r\n                </div>\r\n                <div class=\"card-body\">\r\n                    <p>SB Admin 2 makes extensive use of Bootstrap 4 utility classes in order to reduce CSS bloat and\r\n                        poor page performance. Custom CSS classes are used to create custom components and custom\r\n                        utility classes.</p>\r\n                    <p class=\"mb-0\">Before working with this theme, you should become familiar with the Bootstrap\r\n                        framework, especially the utility classes.</p>\r\n                </div>\r\n            </div>\r\n\r\n        </div>\r\n    </div> -->\r\n</div>\r\n");

/***/ }),

/***/ "./src/app/cooldash/components/footer/footer.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/cooldash/components/footer/footer.component.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Nvb2xkYXNoL2NvbXBvbmVudHMvZm9vdGVyL2Zvb3Rlci5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/cooldash/components/footer/footer.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/cooldash/components/footer/footer.component.ts ***!
  \****************************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let FooterComponent = class FooterComponent {
    constructor() { }
    ngOnInit() {
    }
};
FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-footer',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./footer.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/footer/footer.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./footer.component.scss */ "./src/app/cooldash/components/footer/footer.component.scss")).default]
    })
], FooterComponent);



/***/ }),

/***/ "./src/app/cooldash/components/full/full.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/cooldash/components/full/full.component.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Nvb2xkYXNoL2NvbXBvbmVudHMvZnVsbC9mdWxsLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/cooldash/components/full/full.component.ts":
/*!************************************************************!*\
  !*** ./src/app/cooldash/components/full/full.component.ts ***!
  \************************************************************/
/*! exports provided: FullComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FullComponent", function() { return FullComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var angular_web_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! angular-web-storage */ "./node_modules/angular-web-storage/fesm2015/angular-web-storage.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _assets_js_custom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../assets/js/custom */ "./src/assets/js/custom.js");





let FullComponent = class FullComponent {
    constructor(localStorage, router) {
        this.localStorage = localStorage;
        this.router = router;
    }
    ngOnInit() {
        _assets_js_custom__WEBPACK_IMPORTED_MODULE_4__["removeBg"]();
    }
};
FullComponent.ctorParameters = () => [
    { type: angular_web_storage__WEBPACK_IMPORTED_MODULE_2__["LocalStorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
FullComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-full',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./full.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/full/full.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./full.component.scss */ "./src/app/cooldash/components/full/full.component.scss")).default]
    })
], FullComponent);



/***/ }),

/***/ "./src/app/cooldash/components/header/header.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/cooldash/components/header/header.component.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".modal-dialog {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n          justify-content: center;\n  height: 100%;\n  margin: 0 auto;\n}\n\n.modal-title {\n  color: #000;\n  font-weight: bold;\n}\n\n.modal-body {\n  color: #3c3c3c;\n  font-weight: 400;\n}\n\n.topbar .topbar-divider {\n  margin: auto 0.1rem auto 0.5rem;\n}\n\n@media (max-width: 767px) {\n  li.nav-item a img {\n    margin-right: 0;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2FwcHR1bml4L0Rlc2t0b3AvQ2hpcmFnL01hbmdvL01hemF0L21hemF0X3Jlc3RhdXJhbnQvc3JjL2FwcC9jb29sZGFzaC9jb21wb25lbnRzL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2Nvb2xkYXNoL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHlCQUFBO1VBQUEsbUJBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7QUNDSjs7QURFQTtFQUNJLFdBQUE7RUFDQSxpQkFBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0FDQ0o7O0FERUE7RUFDSSwrQkFBQTtBQ0NKOztBREVBO0VBQ0k7SUFDSSxlQUFBO0VDQ047QUFDRiIsImZpbGUiOiJzcmMvYXBwL2Nvb2xkYXNoL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tb2RhbC1kaWFsb2cge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcblxyXG4ubW9kYWwtdGl0bGUge1xyXG4gICAgY29sb3I6ICMwMDA7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG5cclxuLm1vZGFsLWJvZHkge1xyXG4gICAgY29sb3I6ICMzYzNjM2M7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG59XHJcblxyXG4udG9wYmFyIC50b3BiYXItZGl2aWRlciB7XHJcbiAgICBtYXJnaW46IGF1dG8gMC4xcmVtIGF1dG8gMC41cmVtO1xyXG59XHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcclxuICAgIGxpLm5hdi1pdGVtIGEgaW1nIHtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgICB9XHJcbn0iLCIubW9kYWwtZGlhbG9nIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGhlaWdodDogMTAwJTtcbiAgbWFyZ2luOiAwIGF1dG87XG59XG5cbi5tb2RhbC10aXRsZSB7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLm1vZGFsLWJvZHkge1xuICBjb2xvcjogIzNjM2MzYztcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbn1cblxuLnRvcGJhciAudG9wYmFyLWRpdmlkZXIge1xuICBtYXJnaW46IGF1dG8gMC4xcmVtIGF1dG8gMC41cmVtO1xufVxuXG5AbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgbGkubmF2LWl0ZW0gYSBpbWcge1xuICAgIG1hcmdpbi1yaWdodDogMDtcbiAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/cooldash/components/header/header.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/cooldash/components/header/header.component.ts ***!
  \****************************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var angular_web_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! angular-web-storage */ "./node_modules/angular-web-storage/fesm2015/angular-web-storage.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var ng6_toastr_notifications__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ng6-toastr-notifications */ "./node_modules/ng6-toastr-notifications/fesm2015/ng6-toastr-notifications.js");
/* harmony import */ var _services_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/order.service */ "./src/app/cooldash/services/order.service.ts");






let HeaderComponent = class HeaderComponent {
    constructor(localStorage, router, toastr, orderService) {
        this.localStorage = localStorage;
        this.router = router;
        this.toastr = toastr;
        this.orderService = orderService;
    }
    ngOnInit() {
        if (localStorage.getItem('restaurantLogin')) {
            const data = JSON.parse(localStorage.getItem('restaurantLogin'));
            if (data.id) {
                this.id = data.id;
            }
        }
        this.orderService.newRestaurtOrder().subscribe((res) => {
            console.log(res, res['data'], JSON.parse(res.data));
            if (res && res['data']) {
                const response = JSON.parse(res.data);
                if (response && response['restaurantId'] === this.id) {
                    this.toastr.successToastr('New Restaurant Order Received');
                }
            }
        });
    }
    logout() {
        this.localStorage.clear();
        localStorage.clear();
        document.getElementById('closeLogoutModal').click();
        this.router.navigateByUrl('/login');
    }
};
HeaderComponent.ctorParameters = () => [
    { type: angular_web_storage__WEBPACK_IMPORTED_MODULE_2__["LocalStorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: ng6_toastr_notifications__WEBPACK_IMPORTED_MODULE_4__["ToastrManager"] },
    { type: _services_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"] }
];
HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-header',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/header/header.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./header.component.scss */ "./src/app/cooldash/components/header/header.component.scss")).default]
    })
], HeaderComponent);



/***/ }),

/***/ "./src/app/cooldash/components/sidebar/sidebar.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/cooldash/components/sidebar/sidebar.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".bg-gradient-primary {\n  height: 100% !important;\n  width: 15%;\n  padding-bottom: 0;\n  height: 100%;\n  position: fixed;\n  top: 0;\n  z-index: 3;\n  background-color: #fff;\n  -webkit-transition: all 0.2s ease;\n  transition: all 0.2s ease;\n  box-shadow: 18px 0px 35px 0px rgba(0, 0, 0, 0.02);\n  z-index: 100;\n}\n\nul.navbar-nav.bg-gradient-primary.sidebar.sidebar-dark.accordion.toggled .nav-item a span {\n  opacity: 0;\n  display: none;\n}\n\n.sidebar-brand-icon img {\n  width: auto;\n}\n\n.sidebar-brand-text img {\n  width: auto;\n  height: 70px;\n}\n\n.navbar-nav.bg-gradient-primary.sidebar.sidebar-dark.accordion .sidebar-brand-icon {\n  display: none;\n}\n\n.navbar-nav.bg-gradient-primary.sidebar.sidebar-dark.accordion.toggled .sidebar-brand-icon {\n  display: block;\n}\n\n.sidebar .sidebar-brand {\n  height: auto !important;\n  text-align: left !important;\n  -webkit-box-align: start !important;\n          align-items: flex-start !important;\n  -webkit-box-pack: start !important;\n          justify-content: flex-start !important;\n  padding: 10px 0;\n}\n\nfigure {\n  margin-bottom: 0 !important;\n}\n\n.navbar-nav.sidebar.sidebar-dark.accordion.toggled a.sidebar-brand {\n  -webkit-box-align: center !important;\n          align-items: center !important;\n  -webkit-box-pack: center !important;\n          justify-content: center !important;\n}\n\n.logo-bold {\n  font-size: 26px;\n  color: #000;\n}\n\n.sidebar .nav-item .nav-link {\n  padding: 0.825rem 1rem;\n}\n\n.sidebar li img {\n  margin-right: 10px;\n}\n\n.sidebar-brand-text figure {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n}\n\n.sidebar-brand-text figure img {\n  position: relative;\n  top: -1px;\n}\n\n.sidebar .nav-item img {\n  -webkit-filter: invert(0.5);\n          filter: invert(0.5);\n}\n\n.sidebar .nav-item.active img {\n  -webkit-filter: invert(0.5);\n          filter: invert(0.5);\n}\n\n@media (max-width: 767px) {\n  .sidebar .sidebar-brand .sidebar-brand-text {\n    display: none;\n  }\n\n  .logo-bold {\n    display: none;\n  }\n\n  li.nav-item a img {\n    margin-right: 0;\n  }\n\n  .sidebar .nav-item .nav-link span {\n    font-size: 0.775rem !important;\n    display: none;\n  }\n\n  .sidebar-brand-text img {\n    padding-right: 0;\n    left: 10px;\n  }\n\n  .sidebar {\n    left: -104px;\n    position: relative;\n    width: 0rem;\n  }\n\n  .sidebar.toggled {\n    width: 6.4rem !important;\n    left: 0;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2FwcHR1bml4L0Rlc2t0b3AvQ2hpcmFnL01hbmdvL01hemF0L21hemF0X3Jlc3RhdXJhbnQvc3JjL2FwcC9jb29sZGFzaC9jb21wb25lbnRzL3NpZGViYXIvc2lkZWJhci5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvY29vbGRhc2gvY29tcG9uZW50cy9zaWRlYmFyL3NpZGViYXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx1QkFBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsTUFBQTtFQUNBLFVBQUE7RUFDQSxzQkFBQTtFQUNBLGlDQUFBO0VBQUEseUJBQUE7RUFDQSxpREFBQTtFQUNBLFlBQUE7QUNDSjs7QURFQTtFQUNJLFVBQUE7RUFDQSxhQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQ0NKOztBREVBO0VBQ0ksYUFBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtBQ0NKOztBREVBO0VBQ0ksdUJBQUE7RUFDQSwyQkFBQTtFQUNBLG1DQUFBO1VBQUEsa0NBQUE7RUFDQSxrQ0FBQTtVQUFBLHNDQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVBO0VBQ0ksMkJBQUE7QUNDSjs7QURFQTtFQUNJLG9DQUFBO1VBQUEsOEJBQUE7RUFDQSxtQ0FBQTtVQUFBLGtDQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVBO0VBQ0ksc0JBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7QUNDSjs7QURFQTtFQUNJLDJCQUFBO1VBQUEsbUJBQUE7QUNDSjs7QURFQTtFQUNJLDJCQUFBO1VBQUEsbUJBQUE7QUNDSjs7QURFQTtFQUNJO0lBQ0ksYUFBQTtFQ0NOOztFRENFO0lBQ0ksYUFBQTtFQ0VOOztFREFFO0lBQ0ksZUFBQTtFQ0dOOztFRERFO0lBQ0ksOEJBQUE7SUFDQSxhQUFBO0VDSU47O0VERkU7SUFDSSxnQkFBQTtJQUNBLFVBQUE7RUNLTjs7RURIRTtJQUNJLFlBQUE7SUFDQSxrQkFBQTtJQUNBLFdBQUE7RUNNTjs7RURKRTtJQUNJLHdCQUFBO0lBQ0EsT0FBQTtFQ09OO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9jb29sZGFzaC9jb21wb25lbnRzL3NpZGViYXIvc2lkZWJhci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5iZy1ncmFkaWVudC1wcmltYXJ5IHtcclxuICAgIGhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xyXG4gICAgd2lkdGg6IDE1JTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAwO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgei1pbmRleDogMztcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjJzIGVhc2U7XHJcbiAgICBib3gtc2hhZG93OiAxOHB4IDBweCAzNXB4IDBweCByZ2JhKDAsIDAsIDAsIDAuMDIpO1xyXG4gICAgei1pbmRleDogMTAwO1xyXG59XHJcblxyXG51bC5uYXZiYXItbmF2LmJnLWdyYWRpZW50LXByaW1hcnkuc2lkZWJhci5zaWRlYmFyLWRhcmsuYWNjb3JkaW9uLnRvZ2dsZWQgLm5hdi1pdGVtIGEgc3BhbiB7XHJcbiAgICBvcGFjaXR5OiAwO1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuLnNpZGViYXItYnJhbmQtaWNvbiBpbWcge1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbn1cclxuXHJcbi5zaWRlYmFyLWJyYW5kLXRleHQgaW1nIHtcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgaGVpZ2h0OiA3MHB4O1xyXG59XHJcblxyXG4ubmF2YmFyLW5hdi5iZy1ncmFkaWVudC1wcmltYXJ5LnNpZGViYXIuc2lkZWJhci1kYXJrLmFjY29yZGlvbiAuc2lkZWJhci1icmFuZC1pY29uIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbi5uYXZiYXItbmF2LmJnLWdyYWRpZW50LXByaW1hcnkuc2lkZWJhci5zaWRlYmFyLWRhcmsuYWNjb3JkaW9uLnRvZ2dsZWQgLnNpZGViYXItYnJhbmQtaWNvbiB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLnNpZGViYXIgLnNpZGViYXItYnJhbmQge1xyXG4gICAgaGVpZ2h0OiBhdXRvICFpbXBvcnRhbnQ7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0ICFpbXBvcnRhbnQ7XHJcbiAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydCAhaW1wb3J0YW50O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0ICFpbXBvcnRhbnQ7XHJcbiAgICBwYWRkaW5nOiAxMHB4IDA7XHJcbn1cclxuXHJcbmZpZ3VyZSB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5uYXZiYXItbmF2LnNpZGViYXIuc2lkZWJhci1kYXJrLmFjY29yZGlvbi50b2dnbGVkIGEuc2lkZWJhci1icmFuZCB7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyICFpbXBvcnRhbnQ7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlciAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubG9nby1ib2xkIHtcclxuICAgIGZvbnQtc2l6ZTogMjZweDtcclxuICAgIGNvbG9yOiAjMDAwO1xyXG59XHJcblxyXG4uc2lkZWJhciAubmF2LWl0ZW0gLm5hdi1saW5rIHtcclxuICAgIHBhZGRpbmc6IDAuODI1cmVtIDFyZW07XHJcbn1cclxuXHJcbi5zaWRlYmFyIGxpIGltZyB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbn1cclxuXHJcbi5zaWRlYmFyLWJyYW5kLXRleHQgZmlndXJlIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uc2lkZWJhci1icmFuZC10ZXh0IGZpZ3VyZSBpbWcge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAtMXB4O1xyXG59XHJcblxyXG4uc2lkZWJhciAubmF2LWl0ZW0gaW1nIHtcclxuICAgIGZpbHRlcjogaW52ZXJ0KDAuNSk7XHJcbn1cclxuXHJcbi5zaWRlYmFyIC5uYXYtaXRlbS5hY3RpdmUgaW1nIHtcclxuICAgIGZpbHRlcjogaW52ZXJ0KDAuNSk7XHJcbn1cclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xyXG4gICAgLnNpZGViYXIgLnNpZGViYXItYnJhbmQgLnNpZGViYXItYnJhbmQtdGV4dCB7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZVxyXG4gICAgfVxyXG4gICAgLmxvZ28tYm9sZCB7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgIH1cclxuICAgIGxpLm5hdi1pdGVtIGEgaW1nIHtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgICB9XHJcbiAgICAuc2lkZWJhciAubmF2LWl0ZW0gLm5hdi1saW5rIHNwYW4ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMC43NzVyZW0gIWltcG9ydGFudDtcclxuICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgfVxyXG4gICAgLnNpZGViYXItYnJhbmQtdGV4dCBpbWcge1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDA7XHJcbiAgICAgICAgbGVmdDogMTBweDtcclxuICAgIH1cclxuICAgIC5zaWRlYmFyIHtcclxuICAgICAgICBsZWZ0OiAtMTA0cHg7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHdpZHRoOiAwcmVtO1xyXG4gICAgfVxyXG4gICAgLnNpZGViYXIudG9nZ2xlZCB7XHJcbiAgICAgICAgd2lkdGg6IDYuNHJlbSAhaW1wb3J0YW50O1xyXG4gICAgICAgIGxlZnQ6IDA7XHJcbiAgICB9XHJcbn0iLCIuYmctZ3JhZGllbnQtcHJpbWFyeSB7XG4gIGhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xuICB3aWR0aDogMTUlO1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbiAgaGVpZ2h0OiAxMDAlO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHRvcDogMDtcbiAgei1pbmRleDogMztcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgdHJhbnNpdGlvbjogYWxsIDAuMnMgZWFzZTtcbiAgYm94LXNoYWRvdzogMThweCAwcHggMzVweCAwcHggcmdiYSgwLCAwLCAwLCAwLjAyKTtcbiAgei1pbmRleDogMTAwO1xufVxuXG51bC5uYXZiYXItbmF2LmJnLWdyYWRpZW50LXByaW1hcnkuc2lkZWJhci5zaWRlYmFyLWRhcmsuYWNjb3JkaW9uLnRvZ2dsZWQgLm5hdi1pdGVtIGEgc3BhbiB7XG4gIG9wYWNpdHk6IDA7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5zaWRlYmFyLWJyYW5kLWljb24gaW1nIHtcbiAgd2lkdGg6IGF1dG87XG59XG5cbi5zaWRlYmFyLWJyYW5kLXRleHQgaW1nIHtcbiAgd2lkdGg6IGF1dG87XG4gIGhlaWdodDogNzBweDtcbn1cblxuLm5hdmJhci1uYXYuYmctZ3JhZGllbnQtcHJpbWFyeS5zaWRlYmFyLnNpZGViYXItZGFyay5hY2NvcmRpb24gLnNpZGViYXItYnJhbmQtaWNvbiB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5uYXZiYXItbmF2LmJnLWdyYWRpZW50LXByaW1hcnkuc2lkZWJhci5zaWRlYmFyLWRhcmsuYWNjb3JkaW9uLnRvZ2dsZWQgLnNpZGViYXItYnJhbmQtaWNvbiB7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4uc2lkZWJhciAuc2lkZWJhci1icmFuZCB7XG4gIGhlaWdodDogYXV0byAhaW1wb3J0YW50O1xuICB0ZXh0LWFsaWduOiBsZWZ0ICFpbXBvcnRhbnQ7XG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0ICFpbXBvcnRhbnQ7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydCAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiAxMHB4IDA7XG59XG5cbmZpZ3VyZSB7XG4gIG1hcmdpbi1ib3R0b206IDAgIWltcG9ydGFudDtcbn1cblxuLm5hdmJhci1uYXYuc2lkZWJhci5zaWRlYmFyLWRhcmsuYWNjb3JkaW9uLnRvZ2dsZWQgYS5zaWRlYmFyLWJyYW5kIHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlciAhaW1wb3J0YW50O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlciAhaW1wb3J0YW50O1xufVxuXG4ubG9nby1ib2xkIHtcbiAgZm9udC1zaXplOiAyNnB4O1xuICBjb2xvcjogIzAwMDtcbn1cblxuLnNpZGViYXIgLm5hdi1pdGVtIC5uYXYtbGluayB7XG4gIHBhZGRpbmc6IDAuODI1cmVtIDFyZW07XG59XG5cbi5zaWRlYmFyIGxpIGltZyB7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuLnNpZGViYXItYnJhbmQtdGV4dCBmaWd1cmUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uc2lkZWJhci1icmFuZC10ZXh0IGZpZ3VyZSBpbWcge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogLTFweDtcbn1cblxuLnNpZGViYXIgLm5hdi1pdGVtIGltZyB7XG4gIGZpbHRlcjogaW52ZXJ0KDAuNSk7XG59XG5cbi5zaWRlYmFyIC5uYXYtaXRlbS5hY3RpdmUgaW1nIHtcbiAgZmlsdGVyOiBpbnZlcnQoMC41KTtcbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gIC5zaWRlYmFyIC5zaWRlYmFyLWJyYW5kIC5zaWRlYmFyLWJyYW5kLXRleHQge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICAubG9nby1ib2xkIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG5cbiAgbGkubmF2LWl0ZW0gYSBpbWcge1xuICAgIG1hcmdpbi1yaWdodDogMDtcbiAgfVxuXG4gIC5zaWRlYmFyIC5uYXYtaXRlbSAubmF2LWxpbmsgc3BhbiB7XG4gICAgZm9udC1zaXplOiAwLjc3NXJlbSAhaW1wb3J0YW50O1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICAuc2lkZWJhci1icmFuZC10ZXh0IGltZyB7XG4gICAgcGFkZGluZy1yaWdodDogMDtcbiAgICBsZWZ0OiAxMHB4O1xuICB9XG5cbiAgLnNpZGViYXIge1xuICAgIGxlZnQ6IC0xMDRweDtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgd2lkdGg6IDByZW07XG4gIH1cblxuICAuc2lkZWJhci50b2dnbGVkIHtcbiAgICB3aWR0aDogNi40cmVtICFpbXBvcnRhbnQ7XG4gICAgbGVmdDogMDtcbiAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/cooldash/components/sidebar/sidebar.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/cooldash/components/sidebar/sidebar.component.ts ***!
  \******************************************************************/
/*! exports provided: SidebarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarComponent", function() { return SidebarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _assets_js_custom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../assets/js/custom */ "./src/assets/js/custom.js");



let SidebarComponent = class SidebarComponent {
    constructor() {
        this.menuItems = [];
        (this.dashboard = "assets/icon/dashboard.png"),
            (this.user = "assets/icon/user.png");
        this.category = "assets/icon/category.png";
        this.product = "assets/icon/product.png";
        this.inventory = "assets/icon/inventory.png";
        this.subcategory = "assets/icon/sub-category.png";
        this.order = "assets/icon/order.png";
        this.businessType = "assets/icon/business.png";
        this.setting = "assets/icon/gear.png";
        this.location = "assets/icon/location.png";
        this.subadmin = "assets/icon/driver.png";
        this.driver = "assets/icon/driver-icon.png";
        this.banner = "assets/icon/banner.png";
        this.merchant = "assets/icon/admin-icon.png";
    }
    ngOnInit() {
        _assets_js_custom__WEBPACK_IMPORTED_MODULE_2__["customScript"]();
        this.menuItems = [
            {
                path: "/dashboard",
                title: "Dashboard",
                icon: "assets/icon/dashboard.png",
                class: "sub",
                id: 1
            },
            {
                path: "/restaurant/outlet",
                title: "Outlet",
                icon: "assets/icon/location.png",
                class: "sub"
            },
            {
                path: "/restaurant/food-type",
                title: "Food Category",
                icon: "assets/icon/product.png",
                class: "sub"
            },
            {
                path: "/restaurant/food-item",
                title: "Food Item",
                icon: "assets/icon/inventory.png",
                class: "sub"
            },
            {
                path: '/restaurant/add-ons',
                title: 'Food Add-Ons',
                icon: 'assets/icon/inventory.png',
                class: 'sub'
            },
            {
                path: "/restaurant/order",
                title: "Order",
                icon: "assets/icon/order.png",
                class: "sub"
            },
            {
                path: "/restaurant/profile",
                title: "Profile",
                icon: "assets/icon/profile.png",
                class: "sub"
            },
            {
                path: "/change-password",
                title: "Change Password",
                icon: "assets/icon/password.png",
                class: "sub"
            }
        ];
        if (JSON.stringify(localStorage.getItem("role"))) {
            this.role = JSON.parse(localStorage.getItem("role"));
            this.access = JSON.parse(localStorage.getItem("access"));
        }
    }
};
SidebarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-sidebar",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./sidebar.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/components/sidebar/sidebar.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./sidebar.component.scss */ "./src/app/cooldash/components/sidebar/sidebar.component.scss")).default]
    })
], SidebarComponent);



/***/ }),

/***/ "./src/app/cooldash/cooldash-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/cooldash/cooldash-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: CoolDashRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoolDashRoutingModule", function() { return CoolDashRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _cooldash_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cooldash.component */ "./src/app/cooldash/cooldash.component.ts");
/* harmony import */ var _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/dashboard/dashboard.component */ "./src/app/cooldash/pages/dashboard/dashboard.component.ts");
/* harmony import */ var _pages_change_password_change_password_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/change-password/change-password.component */ "./src/app/cooldash/pages/change-password/change-password.component.ts");





// import { RestaurantModule } from "./pages/restaurant/restaurant.module";

const routes = [
    {
        path: "",
        component: _cooldash_component__WEBPACK_IMPORTED_MODULE_3__["CoolDashComponent"],
        children: [
            { path: "dashboard", component: _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_4__["DashboardComponent"] },
            {
                path: "restaurant",
                loadChildren: () => Promise.all(/*! import() | pages-restaurant-restaurant-module */[__webpack_require__.e("common"), __webpack_require__.e("pages-restaurant-restaurant-module")]).then(__webpack_require__.bind(null, /*! ./pages/restaurant/restaurant.module */ "./src/app/cooldash/pages/restaurant/restaurant.module.ts")).then(m => m.RestaurantModule)
            },
            { path: "change-password", component: _pages_change_password_change_password_component__WEBPACK_IMPORTED_MODULE_5__["ChangePasswordComponent"] }
            // {
            //   path: "store",
            //   loadChildren: () =>
            //     import("./pages/store/store.module").then(m => m.StoreModule)
            // }
            // { path: 'sub-categories', component: SubCategoryComponent },
            // { path: 'users', component: UsersComponent},
            // { path: 'add-user', component: AddUserComponent },
            // { path: 'edit-user/:id', component: EditUserComponent },
            // { path: 'merchant', component: MerchantComponent },
            // { path: 'drivers', component: DriverComponent },
            // { path: 'add-driver', component: AddDriverComponent },
            // { path: 'document/:id', component: DocumentComponent },
            // { path: 'edit-driver/:id', component: EditDriverComponent },
            // { path: 'user-address', component: UserModalComponent },
            //  { path: 'order', loadChildren: () => import('../b2b/pages/order/order.module').then(m => m.OrderModule) },
            // { path: 'products', loadChildren: () => import('../b2b/pages/product/product.module').then(m => m.ProductModule) },
            // { path: 'inventory', component: InventoryComponent },
            // {path: 'banner', loadChildren: () => import('../b2b/pages/banner/banner.module').then(m => m.BannerModule)},
            // {path: 'businessType', loadChildren: () => import('../b2b/pages/business-type/business-type.module').then(m => m.BusinessTypeModule)},
            // { path: 'setting', component: SettingComponent },
            // { path:'geofence',component:GeofenceComponent},
            // { path: 'edit-geofence/:id', component: EditGeofenceComponent },
            // { path: 'add-merchant', component: AddMerchantComponent },
            // { path: 'edit-merchant/:id', component: EditMerchantComponent },
            // { path: 'sub-admin', component: SubAdminComponent },
            // { path: 'add-sub-admin', component: AddSubAdminComponent },
            // { path: 'edit-sub-admin/:id', component: EditSubAdminComponent },
        ]
    }
];
let CoolDashRoutingModule = class CoolDashRoutingModule {
};
CoolDashRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], CoolDashRoutingModule);



/***/ }),

/***/ "./src/app/cooldash/cooldash.component.scss":
/*!**************************************************!*\
  !*** ./src/app/cooldash/cooldash.component.scss ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Nvb2xkYXNoL2Nvb2xkYXNoLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/cooldash/cooldash.component.ts":
/*!************************************************!*\
  !*** ./src/app/cooldash/cooldash.component.ts ***!
  \************************************************/
/*! exports provided: CoolDashComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoolDashComponent", function() { return CoolDashComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let CoolDashComponent = class CoolDashComponent {
    constructor() { }
    ngOnInit() { }
};
CoolDashComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-cool-dash",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./cooldash.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/cooldash.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./cooldash.component.scss */ "./src/app/cooldash/cooldash.component.scss")).default]
    })
], CoolDashComponent);



/***/ }),

/***/ "./src/app/cooldash/cooldash.module.ts":
/*!*********************************************!*\
  !*** ./src/app/cooldash/cooldash.module.ts ***!
  \*********************************************/
/*! exports provided: CoolDashModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoolDashModule", function() { return CoolDashModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _cooldash_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cooldash-routing.module */ "./src/app/cooldash/cooldash-routing.module.ts");
/* harmony import */ var _cooldash_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./cooldash.component */ "./src/app/cooldash/cooldash.component.ts");
/* harmony import */ var _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/footer/footer.component */ "./src/app/cooldash/components/footer/footer.component.ts");
/* harmony import */ var _components_full_full_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/full/full.component */ "./src/app/cooldash/components/full/full.component.ts");
/* harmony import */ var _components_header_header_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/header/header.component */ "./src/app/cooldash/components/header/header.component.ts");
/* harmony import */ var _components_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/sidebar/sidebar.component */ "./src/app/cooldash/components/sidebar/sidebar.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/dashboard/dashboard.component */ "./src/app/cooldash/pages/dashboard/dashboard.component.ts");
/* harmony import */ var _pages_material_material_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./pages/material/material.module */ "./src/app/cooldash/pages/material/material.module.ts");
/* harmony import */ var _pages_change_password_change_password_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pages/change-password/change-password.component */ "./src/app/cooldash/pages/change-password/change-password.component.ts");














let CoolDashModule = class CoolDashModule {
};
CoolDashModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _cooldash_component__WEBPACK_IMPORTED_MODULE_4__["CoolDashComponent"],
            _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_5__["FooterComponent"],
            _components_full_full_component__WEBPACK_IMPORTED_MODULE_6__["FullComponent"],
            _components_header_header_component__WEBPACK_IMPORTED_MODULE_7__["HeaderComponent"],
            _components_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_8__["SidebarComponent"],
            _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_10__["DashboardComponent"],
            _pages_change_password_change_password_component__WEBPACK_IMPORTED_MODULE_12__["ChangePasswordComponent"]
        ],
        exports: [],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormsModule"],
            _cooldash_routing_module__WEBPACK_IMPORTED_MODULE_3__["CoolDashRoutingModule"],
            _pages_material_material_module__WEBPACK_IMPORTED_MODULE_11__["MaterialModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ReactiveFormsModule"]
        ]
    })
], CoolDashModule);



/***/ }),

/***/ "./src/app/cooldash/pages/change-password/change-password.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/cooldash/pages/change-password/change-password.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".invalid-feedback {\n  display: block;\n  width: 100%;\n  margin-top: 0.14rem;\n  margin-left: 0.6rem;\n  font-size: 95%;\n  color: #f55353;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2FwcHR1bml4L0Rlc2t0b3AvQ2hpcmFnL01hbmdvL01hemF0L21hemF0X3Jlc3RhdXJhbnQvc3JjL2FwcC9jb29sZGFzaC9wYWdlcy9jaGFuZ2UtcGFzc3dvcmQvY2hhbmdlLXBhc3N3b3JkLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb29sZGFzaC9wYWdlcy9jaGFuZ2UtcGFzc3dvcmQvY2hhbmdlLXBhc3N3b3JkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL2Nvb2xkYXNoL3BhZ2VzL2NoYW5nZS1wYXNzd29yZC9jaGFuZ2UtcGFzc3dvcmQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaW52YWxpZC1mZWVkYmFjayB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWFyZ2luLXRvcDogMC4xNHJlbTtcclxuICAgIG1hcmdpbi1sZWZ0OiAwLjZyZW07XHJcbiAgICBmb250LXNpemU6IDk1JTtcclxuICAgIGNvbG9yOiAjZjU1MzUzO1xyXG4gIH1cclxuICIsIi5pbnZhbGlkLWZlZWRiYWNrIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tdG9wOiAwLjE0cmVtO1xuICBtYXJnaW4tbGVmdDogMC42cmVtO1xuICBmb250LXNpemU6IDk1JTtcbiAgY29sb3I6ICNmNTUzNTM7XG59Il19 */");

/***/ }),

/***/ "./src/app/cooldash/pages/change-password/change-password.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/cooldash/pages/change-password/change-password.component.ts ***!
  \*****************************************************************************/
/*! exports provided: ChangePasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePasswordComponent", function() { return ChangePasswordComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/api/api.service */ "./src/app/cooldash/services/api/api.service.ts");
/* harmony import */ var ng6_toastr_notifications__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng6-toastr-notifications */ "./node_modules/ng6-toastr-notifications/fesm2015/ng6-toastr-notifications.js");






let ChangePasswordComponent = class ChangePasswordComponent {
    constructor(api, toastr, router, formBuilder) {
        this.api = api;
        this.toastr = toastr;
        this.router = router;
        this.formBuilder = formBuilder;
        this.submitted = false;
        this.history = window.history;
    }
    ngOnInit() {
        if (localStorage.getItem("restaurantLogin")) {
            var data = JSON.parse(localStorage.getItem("restaurantLogin"));
            if (data.id) {
                this.id = data.id;
            }
        }
        this.resetPasswordForm = this.formBuilder.group({
            oldPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]("", _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required
            ])),
            newPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]("", _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(8),
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].maxLength(25)
            ])),
            confirmPassword: [""]
        }, { validator: this.checkPasswords });
    }
    checkPasswords(group) {
        let pass = group.get("newPassword").value;
        let confirmPass = group.get("confirmPassword").value;
        return pass === confirmPass ? null : { notSame: true };
    }
    update() {
        this.submitted = true;
        if (this.submitted && this.resetPasswordForm.valid) {
            var data = {
                id: this.id,
                oldPassword: this.resetPasswordForm.controls['oldPassword'].value,
                newPassword: this.resetPasswordForm.controls['newPassword'].value,
                verticalType: 0
            };
            this.api.changePassword(data).subscribe(res => {
                if (res['response']['success']) {
                    this.toastr.successToastr(res['response']['message']);
                    this.router.navigate(['/']);
                }
                else {
                    this.toastr.warningToastr(res['response']['message']);
                }
            }, err => {
                console.log(err);
            });
        }
        else {
            this.resetPasswordForm.markAllAsTouched();
        }
    }
    ;
};
ChangePasswordComponent.ctorParameters = () => [
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"] },
    { type: ng6_toastr_notifications__WEBPACK_IMPORTED_MODULE_5__["ToastrManager"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] }
];
ChangePasswordComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-change-password',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./change-password.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/pages/change-password/change-password.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./change-password.component.scss */ "./src/app/cooldash/pages/change-password/change-password.component.scss")).default]
    })
], ChangePasswordComponent);



/***/ }),

/***/ "./src/app/cooldash/pages/dashboard/dashboard.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/cooldash/pages/dashboard/dashboard.component.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Nvb2xkYXNoL3BhZ2VzL2Rhc2hib2FyZC9kYXNoYm9hcmQuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/cooldash/pages/dashboard/dashboard.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/cooldash/pages/dashboard/dashboard.component.ts ***!
  \*****************************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_url_url_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/url/url.service */ "./src/app/cooldash/services/url/url.service.ts");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/api/api.service */ "./src/app/cooldash/services/api/api.service.ts");
/* harmony import */ var _services_common_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/common/common.service */ "./src/app/cooldash/services/common/common.service.ts");





// import { Resp } from "src/app/models/Resp";
let DashboardComponent = class DashboardComponent {
    constructor(api, url, commService) {
        this.api = api;
        this.url = url;
        this.commService = commService;
    }
    ngOnInit() {
        if (localStorage.getItem("restaurantLogin")) {
            var data = JSON.parse(localStorage.getItem("restaurantLogin"));
            if (data.id) {
                this.id = data.id;
                this.getRestaurantById(this.id);
            }
        }
    }
    getRestaurantById(id) {
        this.api.getResturantById(id).subscribe(res => {
            if (res["response"]["success"]) {
                console.log(res);
                this.restaurantDetail = res["data"];
                console.log(this.restaurantDetail);
            }
        });
    }
};
DashboardComponent.ctorParameters = () => [
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] },
    { type: _services_url_url_service__WEBPACK_IMPORTED_MODULE_2__["UrlService"] },
    { type: _services_common_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"] }
];
DashboardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-dashboard",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./dashboard.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cooldash/pages/dashboard/dashboard.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./dashboard.component.scss */ "./src/app/cooldash/pages/dashboard/dashboard.component.scss")).default]
    })
], DashboardComponent);



/***/ }),

/***/ "./src/assets/js/custom.js":
/*!*********************************!*\
  !*** ./src/assets/js/custom.js ***!
  \*********************************/
/*! exports provided: pieChart, chartAreaDemo, bgScript, removeBg, customScript, toggleSwitch */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pieChart", function() { return pieChart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "chartAreaDemo", function() { return chartAreaDemo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bgScript", function() { return bgScript; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeBg", function() { return removeBg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "customScript", function() { return customScript; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toggleSwitch", function() { return toggleSwitch; });
var pieChart = function () {
  // Set new default font family and font color to mimic Bootstrap's default styling
  Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
  Chart.defaults.global.defaultFontColor = '#858796';

// Pie Chart Example
  var ctx = document.getElementById("myPieChart");
  var myPieChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ["Direct", "Referral", "Social"],
      datasets: [{
        data: [55, 30, 15],
        backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
        hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
        hoverBorderColor: "rgba(234, 236, 244, 1)",
      }],
    },
    options: {
      maintainAspectRatio: false,
      tooltips: {
        backgroundColor: "rgb(255,255,255)",
        bodyFontColor: "#858796",
        borderColor: '#dddfeb',
        borderWidth: 1,
        xPadding: 15,
        yPadding: 15,
        displayColors: false,
        caretPadding: 10,
      },
      legend: {
        display: false
      },
      cutoutPercentage: 80,
    },
  });
};
var chartAreaDemo = function () {
  // Set new default font family and font color to mimic Bootstrap's default styling
  Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
  Chart.defaults.global.defaultFontColor = '#858796';

  function number_format(number, decimals, dec_point, thousands_sep) {
    // *     example: number_format(1234.56, 2, ',', ' ');
    // *     return: '1 234,56'
    number = (number + '').replace(',', '').replace(' ', '');
    var n = !isFinite(+number) ? 0 : +number,
      prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
      sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
      dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
      s = '',
      toFixedFix = function(n, prec) {
        var k = Math.pow(10, prec);
        return '' + Math.round(n * k) / k;
      };
    // Fix for IE parseFloat(0.55).toFixed(0) = 0;
    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    if (s[0].length > 3) {
      s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }
    if ((s[1] || '').length < prec) {
      s[1] = s[1] || '';
      s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
  }

// Area Chart Example
  var ctx = document.getElementById("myAreaChart");
  var myLineChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      datasets: [{
        label: "Earnings",
        lineTension: 0.3,
        backgroundColor: "rgba(78, 115, 223, 0.05)",
        borderColor: "rgba(78, 115, 223, 1)",
        pointRadius: 3,
        pointBackgroundColor: "rgba(78, 115, 223, 1)",
        pointBorderColor: "rgba(78, 115, 223, 1)",
        pointHoverRadius: 3,
        pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
        pointHoverBorderColor: "rgba(78, 115, 223, 1)",
        pointHitRadius: 10,
        pointBorderWidth: 2,
        data: [0, 10000, 5000, 15000, 10000, 20000, 15000, 25000, 20000, 30000, 25000, 40000],
      }],
    },
    options: {
      maintainAspectRatio: false,
      layout: {
        padding: {
          left: 10,
          right: 25,
          top: 25,
          bottom: 0
        }
      },
      scales: {
        xAxes: [{
          time: {
            unit: 'date'
          },
          gridLines: {
            display: false,
            drawBorder: false
          },
          ticks: {
            maxTicksLimit: 7
          }
        }],
        yAxes: [{
          ticks: {
            maxTicksLimit: 5,
            padding: 10,
            // Include a dollar sign in the ticks
            callback: function(value, index, values) {
              return '$' + number_format(value);
            }
          },
          gridLines: {
            color: "rgb(234, 236, 244)",
            zeroLineColor: "rgb(234, 236, 244)",
            drawBorder: false,
            borderDash: [2],
            zeroLineBorderDash: [2]
          }
        }],
      },
      legend: {
        display: false
      },
      tooltips: {
        backgroundColor: "rgb(255,255,255)",
        bodyFontColor: "#858796",
        titleMarginBottom: 10,
        titleFontColor: '#6e707e',
        titleFontSize: 14,
        borderColor: '#dddfeb',
        borderWidth: 1,
        xPadding: 15,
        yPadding: 15,
        displayColors: false,
        intersect: false,
        mode: 'index',
        caretPadding: 10,
        callbacks: {
          label: function(tooltipItem, chart) {
            var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
            return datasetLabel + ': $' + number_format(tooltipItem.yLabel);
          }
        }
      }
    }
  });
};
var bgScript = function () {
  $('body').addClass('bg-gradient-primary');
};
var removeBg = function () {
  $('body').removeClass('bg-gradient-primary');
};
var customScript = function () {
  setTimeout(() => {
    // Toggle the side navigation
    $("#sidebarToggle, #sidebarToggleTop").on('click', function(e) {
      $("body").toggleClass("sidebar-toggled");
      $(".sidebar").toggleClass("toggled");
      if ($(".sidebar").hasClass("toggled")) {
        $('.sidebar .collapse').collapse('hide');
      };
    });

    // Close any open menu accordions when window is resized below 768px
    $(window).resize(function() {
      if ($(window).width() < 768) {
        $('.sidebar .collapse').collapse('hide');
      };
    });

    // Prevent the content wrapper from scrolling when the fixed side navigation hovered over
    $('body.fixed-nav .sidebar').on('mousewheel DOMMouseScroll wheel', function(e) {
      if ($(window).width() > 768) {
        var e0 = e.originalEvent,
          delta = e0.wheelDelta || -e0.detail;
        this.scrollTop += (delta < 0 ? 1 : -1) * 30;
        e.preventDefault();
      }
    });

    // Scroll to top button appear
    $(document).on('scroll', function() {
      var scrollDistance = $(this).scrollTop();
      if (scrollDistance > 100) {
        $('.scroll-to-top').fadeIn();
      } else {
        $('.scroll-to-top').fadeOut();
      }
    });

    // Smooth scrolling using jQuery easing
    $(document).on('click', 'a.scroll-to-top', function(e) {
      $("html, body").animate({scrollTop: 0}, 1000);
    });
  }, 2000);
};
var toggleSwitch = function () {
  $('.couponToggle').bootstrapToggle();
};


/***/ })

}]);
//# sourceMappingURL=cooldash-cooldash-module-es2015.js.map