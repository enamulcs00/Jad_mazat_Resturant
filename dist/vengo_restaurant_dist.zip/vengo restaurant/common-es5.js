function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"], {
  /***/
  "./src/app/cooldash/services/popup/popup.service.ts":
  /*!**********************************************************!*\
    !*** ./src/app/cooldash/services/popup/popup.service.ts ***!
    \**********************************************************/

  /*! exports provided: PopupService */

  /***/
  function srcAppCooldashServicesPopupPopupServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PopupService", function () {
      return PopupService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _pages_restaurant_category_categorymodal_categorymodal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../pages/restaurant/category/categorymodal/categorymodal.component */
    "./src/app/cooldash/pages/restaurant/category/categorymodal/categorymodal.component.ts");
    /* harmony import */


    var _pages_restaurant_order_items_modal_items_modal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../pages/restaurant/order/items-modal/items-modal.component */
    "./src/app/cooldash/pages/restaurant/order/items-modal/items-modal.component.ts");
    /* harmony import */


    var _pages_restaurant_order_accept_modal_accept_modal_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../pages/restaurant/order/accept-modal/accept-modal.component */
    "./src/app/cooldash/pages/restaurant/order/accept-modal/accept-modal.component.ts");
    /* harmony import */


    var _pages_restaurant_restaurant_outletmodal_outletmodal_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../pages/restaurant/restaurant/outletmodal/outletmodal.component */
    "./src/app/cooldash/pages/restaurant/restaurant/outletmodal/outletmodal.component.ts");
    /* harmony import */


    var _pages_restaurant_restaurant_food_type_restaurant_type_modal_restaurant_type_modal_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../../pages/restaurant/restaurant/food-type/restaurant-type-modal/restaurant-type-modal.component */
    "./src/app/cooldash/pages/restaurant/restaurant/food-type/restaurant-type-modal/restaurant-type-modal.component.ts");
    /* harmony import */


    var src_app_forgot_password_modal_forgot_password_modal_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! src/app/forgot-password-modal/forgot-password-modal.component */
    "./src/app/forgot-password-modal/forgot-password-modal.component.ts");

    var PopupService = /*#__PURE__*/function () {
      function PopupService(dialog) {
        _classCallCheck(this, PopupService);

        this.dialog = dialog;
      }

      _createClass(PopupService, [{
        key: "addRestaurant",
        value: function addRestaurant() {
          var dialogRef = this.dialog.open(_pages_restaurant_category_categorymodal_categorymodal_component__WEBPACK_IMPORTED_MODULE_3__["CategorymodalComponent"]);
          return dialogRef.afterClosed();
        }
      }, {
        key: "editRestaurant",
        value: function editRestaurant(item) {
          var dialogRef = this.dialog.open(_pages_restaurant_category_categorymodal_categorymodal_component__WEBPACK_IMPORTED_MODULE_3__["CategorymodalComponent"]);
          dialogRef.componentInstance.item = item;
          return dialogRef.afterClosed();
        }
      }, {
        key: "itemList",
        value: function itemList(item) {
          var dialogRef = this.dialog.open(_pages_restaurant_order_items_modal_items_modal_component__WEBPACK_IMPORTED_MODULE_4__["ItemsModalComponent"]);
          dialogRef.componentInstance.items = item;
          return dialogRef.afterClosed();
        }
      }, {
        key: "orderAcceptModal",
        value: function orderAcceptModal() {
          var dialogRef = this.dialog.open(_pages_restaurant_order_accept_modal_accept_modal_component__WEBPACK_IMPORTED_MODULE_5__["AcceptModalComponent"]);
          return dialogRef.afterClosed();
        }
      }, {
        key: "addOutlet",
        value: function addOutlet(id) {
          var dialogRef = this.dialog.open(_pages_restaurant_restaurant_outletmodal_outletmodal_component__WEBPACK_IMPORTED_MODULE_6__["OutletmodalComponent"]);
          dialogRef.componentInstance.restaurantId = id;
          return dialogRef.afterClosed();
        }
      }, {
        key: "editOutlet",
        value: function editOutlet(item) {
          var dialogRef = this.dialog.open(_pages_restaurant_restaurant_outletmodal_outletmodal_component__WEBPACK_IMPORTED_MODULE_6__["OutletmodalComponent"]);
          dialogRef.componentInstance.item = item;
          return dialogRef.afterClosed();
        }
      }, {
        key: "addType",
        value: function addType(id) {
          var dialogRef = this.dialog.open(_pages_restaurant_restaurant_food_type_restaurant_type_modal_restaurant_type_modal_component__WEBPACK_IMPORTED_MODULE_7__["RestaurantTypeModalComponent"]);
          dialogRef.componentInstance.restaurantId = id;
          return dialogRef.afterClosed();
        }
      }, {
        key: "editType",
        value: function editType(item) {
          var dialogRef = this.dialog.open(_pages_restaurant_restaurant_food_type_restaurant_type_modal_restaurant_type_modal_component__WEBPACK_IMPORTED_MODULE_7__["RestaurantTypeModalComponent"]);
          dialogRef.componentInstance.item = item;
          return dialogRef.afterClosed();
        }
      }, {
        key: "forgotPasswordsendEmail",
        value: function forgotPasswordsendEmail() {
          var dialogRef = this.dialog.open(src_app_forgot_password_modal_forgot_password_modal_component__WEBPACK_IMPORTED_MODULE_8__["ForgotPasswordModalComponent"]);
          return dialogRef.afterClosed();
        }
      }]);

      return PopupService;
    }();

    PopupService.ctorParameters = function () {
      return [{
        type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]
      }];
    };

    PopupService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: "root"
    })], PopupService);
    /***/
  }
}]);
//# sourceMappingURL=common-es5.js.map